using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text.Json;
using System.Threading.Channels;
using Microsoft.AspNetCore.Hosting;

namespace SystemsRegistry
{
    /// <summary>
    /// The full registry state, mirroring the shape server.js reads/writes
    /// to sysreg-data.json: { apps, migrations, version, savedAt }.
    /// Apps/Migrations are kept as raw JsonElement rather than strongly
    /// typed classes because the frontend's row shape is open-ended
    /// (arbitrary columns from Excel import) — same approach the Node
    /// version takes by just passing JSON through untouched.
    /// </summary>
    public class RegistryState
    {
        public JsonElement Apps { get; set; }
        public JsonElement Migrations { get; set; }
        public int Version { get; set; }
        public string? SavedAt { get; set; }
    }

    public class SaveResult
    {
        public bool Ok { get; set; }
        public bool Conflict { get; set; }
        public RegistryState State { get; set; } = default!;
    }

    /// <summary>
    /// Singleton, one instance per IIS worker process. Holds the
    /// source-of-truth state in memory, persists it to sysreg-data.json
    /// next to the app on every successful save, and fans out version
    /// change notifications to any open SSE connections.
    ///
    /// Locking: the version compare-and-increment happens inside a plain
    /// `lock`, so two concurrent saves can't both believe they "won" —
    /// exactly the same guarantee server.js gets for free from JavaScript
    /// being single-threaded, just made explicit here since C# requests
    /// can genuinely run in parallel.
    /// </summary>
    public class DataStore
    {
        private readonly string _dataFile;
        private readonly object _lock = new object();
        private RegistryState _state;
        private readonly ConcurrentDictionary<Guid, Channel<string>> _subscribers = new();

        public DataStore(IWebHostEnvironment env)
        {
            _dataFile = Path.Combine(env.ContentRootPath, "sysreg-data.json");
            _state = Load();
        }

        private RegistryState Load()
        {
            try
            {
                var raw = File.ReadAllText(_dataFile);
                using var doc = JsonDocument.Parse(raw);
                var root = doc.RootElement;

                var apps = root.TryGetProperty("apps", out var a) ? a.Clone() : EmptyArray();
                var migrations = root.TryGetProperty("migrations", out var m) ? m.Clone() : EmptyArray();
                var version = root.TryGetProperty("version", out var v) && v.ValueKind == JsonValueKind.Number
                    ? v.GetInt32() : 0;
                var savedAt = root.TryGetProperty("savedAt", out var s) && s.ValueKind == JsonValueKind.String
                    ? s.GetString() : null;

                return new RegistryState { Apps = apps, Migrations = migrations, Version = version, SavedAt = savedAt };
            }
            catch
            {
                // No file yet, or unreadable — start fresh; first save creates it.
                return new RegistryState { Apps = EmptyArray(), Migrations = EmptyArray(), Version = 0, SavedAt = null };
            }
        }

        private static JsonElement EmptyArray()
        {
            using var doc = JsonDocument.Parse("[]");
            return doc.RootElement.Clone();
        }

        public RegistryState GetState()
        {
            lock (_lock)
            {
                return _state;
            }
        }

        /// <summary>
        /// Version-checked save. Returns Conflict=true (without writing
        /// anything) if expectedVersion doesn't match the current version —
        /// i.e. someone else saved in between. Caller is expected to hand
        /// the returned State back to the client so it can show the latest
        /// data instead of silently losing the rejected edit.
        /// </summary>
        public SaveResult TrySave(JsonElement apps, JsonElement migrations, int expectedVersion)
        {
            lock (_lock)
            {
                if (expectedVersion != _state.Version)
                {
                    return new SaveResult { Ok = false, Conflict = true, State = _state };
                }

                var newState = new RegistryState
                {
                    Apps = apps,
                    Migrations = migrations,
                    Version = _state.Version + 1,
                    SavedAt = DateTime.UtcNow.ToString("o")
                };

                var json = JsonSerializer.Serialize(new
                {
                    apps = newState.Apps,
                    migrations = newState.Migrations,
                    version = newState.Version,
                    savedAt = newState.SavedAt
                }, new JsonSerializerOptions { WriteIndented = true });

                File.WriteAllText(_dataFile, json);

                _state = newState;
                return new SaveResult { Ok = true, Conflict = false, State = _state };
            }
        }

        public Guid Subscribe(out Channel<string> channel)
        {
            var id = Guid.NewGuid();
            channel = Channel.CreateUnbounded<string>();
            _subscribers[id] = channel;
            return id;
        }

        public void Unsubscribe(Guid id)
        {
            if (_subscribers.TryRemove(id, out var channel))
            {
                channel.Writer.TryComplete();
            }
        }

        public void Broadcast(int version)
        {
            var payload = $"data: {{\"version\":{version}}}\n\n";
            foreach (var kvp in _subscribers)
            {
                kvp.Value.Writer.TryWrite(payload);
            }
        }
    }
}
