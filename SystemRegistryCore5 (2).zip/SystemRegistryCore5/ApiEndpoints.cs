using System;
using System.Text.Json;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace SystemsRegistry
{
    public static class ApiEndpoints
    {
        private static readonly JsonSerializerOptions ReadOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        public class PostBody
        {
            public JsonElement Apps { get; set; }
            public JsonElement Migrations { get; set; }
            public int ExpectedVersion { get; set; }
        }

        /// <summary>GET /api/data — full current state, used both for the
        /// initial zero-click load and whenever the client needs to catch
        /// up after a live-update notification.</summary>
        public static async Task GetData(HttpContext ctx)
        {
            var store = ctx.RequestServices.GetRequiredService<DataStore>();
            var state = store.GetState();

            ctx.Response.ContentType = "application/json";
            ctx.Response.Headers["Cache-Control"] = "no-store";

            var payload = JsonSerializer.Serialize(new
            {
                apps = state.Apps,
                migrations = state.Migrations,
                version = state.Version,
                savedAt = state.SavedAt
            });
            await ctx.Response.WriteAsync(payload);
        }

        /// <summary>POST /api/data — version-checked save. Mirrors
        /// server.js exactly: 200 + new version on success, 409 + the
        /// current server state if the caller's expectedVersion is stale.</summary>
        public static async Task PostData(HttpContext ctx)
        {
            var store = ctx.RequestServices.GetRequiredService<DataStore>();

            PostBody? body;
            try
            {
                body = await JsonSerializer.DeserializeAsync<PostBody>(ctx.Request.Body, ReadOptions);
            }
            catch (JsonException)
            {
                body = null;
            }

            if (body == null)
            {
                ctx.Response.StatusCode = 400;
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync("{\"ok\":false,\"error\":\"Invalid JSON\"}");
                return;
            }

            if (body.Apps.ValueKind != JsonValueKind.Array || body.Migrations.ValueKind != JsonValueKind.Array)
            {
                ctx.Response.StatusCode = 400;
                ctx.Response.ContentType = "application/json";
                await ctx.Response.WriteAsync("{\"ok\":false,\"error\":\"apps and migrations must be arrays\"}");
                return;
            }

            var result = store.TrySave(body.Apps, body.Migrations, body.ExpectedVersion);

            ctx.Response.ContentType = "application/json";
            ctx.Response.Headers["Cache-Control"] = "no-store";

            if (result.Conflict)
            {
                ctx.Response.StatusCode = 409;
                var conflictPayload = JsonSerializer.Serialize(new
                {
                    ok = false,
                    error = "Data changed since you loaded it",
                    apps = result.State.Apps,
                    migrations = result.State.Migrations,
                    version = result.State.Version
                });
                await ctx.Response.WriteAsync(conflictPayload);
                return;
            }

            ctx.Response.StatusCode = 200;
            await ctx.Response.WriteAsync(JsonSerializer.Serialize(new { ok = true, version = result.State.Version }));

            // Notify every connected client only after the response to the
            // saver has actually been sent.
            store.Broadcast(result.State.Version);
        }

        /// <summary>GET /api/events — Server-Sent Events stream. Pushes
        /// `data: {"version":N}` whenever anyone saves, plus a heartbeat
        /// comment every 25s to keep the connection alive through
        /// anything (VPN, IIS, proxies) that might otherwise time out an
        /// idle connection.</summary>
        public static async Task Events(HttpContext ctx)
        {
            var store = ctx.RequestServices.GetRequiredService<DataStore>();

            ctx.Response.ContentType = "text/event-stream";
            ctx.Response.Headers["Cache-Control"] = "no-store";
            ctx.Response.Headers["Connection"] = "keep-alive";
            // Harmless outside nginx, but prevents accidental buffering if
            // this ever sits behind a proxy that respects this header.
            ctx.Response.Headers["X-Accel-Buffering"] = "no";

            var id = store.Subscribe(out var channel);
            var cancellationToken = ctx.RequestAborted;

            try
            {
                var initial = store.GetState();
                await ctx.Response.WriteAsync($"data: {{\"version\":{initial.Version}}}\n\n", cancellationToken);
                await ctx.Response.Body.FlushAsync(cancellationToken);

                _ = Task.Run(async () =>
                {
                    try
                    {
                        while (!cancellationToken.IsCancellationRequested)
                        {
                            await Task.Delay(TimeSpan.FromSeconds(25), cancellationToken);
                            await channel.Writer.WriteAsync(": heartbeat\n\n", cancellationToken);
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        // Connection closed — expected, nothing to do.
                    }
                }, cancellationToken);

                await foreach (var message in channel.Reader.ReadAllAsync(cancellationToken))
                {
                    await ctx.Response.WriteAsync(message, cancellationToken);
                    await ctx.Response.Body.FlushAsync(cancellationToken);
                }
            }
            catch (OperationCanceledException)
            {
                // Client disconnected/tab closed — normal, not an error.
            }
            finally
            {
                store.Unsubscribe(id);
            }
        }
    }
}
