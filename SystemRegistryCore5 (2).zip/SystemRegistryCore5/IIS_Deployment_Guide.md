# Deploying the ASP.NET Core Version to IIS

This replaces the Node/`server.js` deployment with a native ASP.NET Core 5 app running
**in-process** inside IIS's worker process (`w3wp.exe`) — no separate Node process, no
Task Scheduler workaround needed. The frontend (`Application_Inventory.html`) is unchanged
from before; only the backend was rewritten.

---

## 0. Verify it builds, before touching the server

I wasn't able to compile this in my own environment (no .NET SDK available there), so this
has been carefully reviewed but not build-tested. On your machine, first:

```
cd SystemsRegistry
dotnet build
```

Fix anything that comes up (should be clean, but confirm before deploying) — then optionally
run it locally to sanity-check behavior before IIS is involved at all:

```
dotnet run
```

This starts it on Kestrel at `http://localhost:5080` (see `Properties/launchSettings.json`).
Confirm the page loads and a save works. This isolates "is the app itself correct" from
"is IIS configured correctly," which makes troubleshooting much faster if something's wrong.

---

## 1. Install the .NET 5 Hosting Bundle on the server

This is the one everyone forgets and it's the #1 cause of a blank/500 error after deploying
to IIS. The regular .NET runtime is **not enough** — IIS needs the **ASP.NET Core Module
(ANCM)**, which only comes from the Hosting Bundle.

1. Download **".NET 5.0 Hosting Bundle"** from Microsoft's .NET downloads page (search
   "download .NET 5.0 hosting bundle" — get the Windows Hosting Bundle, not just the SDK
   or Runtime).
2. Run the installer on `cmapps01`.
3. **Restart IIS afterward** so it picks up the new module:
   ```
   net stop was /y
   net start w3svc
   ```
   (or just reboot the server if that's easier)

---

## 2. Publish the app

From your dev machine (or on the server itself, if the SDK's installed there):

```
cd SystemsRegistry
dotnet publish -c Release -o C:\Apps\SystemsRegistry-Publish
```

Copy the entire contents of that output folder to wherever it'll live on `cmapps01`, e.g.:
```
C:\Apps\SystemsRegistry\
```

This output folder will include `SystemsRegistry.dll`, a generated `web.config` (already
configured with `hostingModel="inprocess"` because of the csproj setting), and the
`wwwroot` folder with the HTML in it.

**Note:** `sysreg-data.json` isn't part of the publish output — it gets created automatically
in this same folder the first time anyone saves.

---

## 3. Create the IIS site

1. Open **IIS Manager** on `cmapps01`.
2. **Application Pools** → **Add Application Pool**:
   - Name: `SystemsRegistryPool`
   - **.NET CLR version: "No Managed Code"** — this is important and easy to miss. ASP.NET
     Core doesn't run inside the classic .NET Framework CLR that IIS's managed pipeline
     expects; the ASP.NET Core Module handles everything itself.
   - Managed pipeline mode: doesn't matter (Integrated is fine, default)
3. **Sites** → **Add Website**:
   - Site name: `Systems Registry`
   - Application pool: `SystemsRegistryPool` (the one you just made)
   - Physical path: `C:\Apps\SystemsRegistry` (wherever you published to)
   - Binding: **Type: http, Port: 80** — since that's the port your infra already allows.
     If something else is already bound to port 80 on this box (check with
     `netstat -ano | findstr ":80 "` first, same as before), you'll need to free it up or
     pick a different port and adjust the firewall rule to match.
4. Click **OK**.

---

## 4. Grant the app pool write access to its own folder

The app needs to write `sysreg-data.json` next to itself. IIS application pool identities
are locked down by default and won't have write access to `C:\Apps\SystemsRegistry` unless
you grant it explicitly.

1. Right-click the `C:\Apps\SystemsRegistry` folder → **Properties** → **Security** → **Edit**
2. **Add** → type `IIS AppPool\SystemsRegistryPool` → **Check Names** (it should resolve, this
   is a real, if unusual-looking, Windows identity tied to your specific app pool) → **OK**
3. Give it **Modify** permission (Read/Write/Modify — not Full Control, no need to go that far)
4. Apply.

If you skip this, saves will fail — the app will look like it's running but every POST to
`/api/data` will error out trying to write the file.

---

## 5. Firewall (same as before)

If you didn't already open port 80 during the earlier Node attempt, same steps apply:

**Windows Defender Firewall with Advanced Security** → **Inbound Rules** → **New Rule** →
Port → TCP → `80` → Allow → apply to the relevant profile(s).

---

## 6. Test

1. On `cmapps01` itself: `http://localhost`
2. From another PC (same as before): `http://cmapps01`
3. Specifically test the **live-sync piece** — open the app in two browser tabs (or two
   different machines), save a change in one, and confirm the other updates within a couple
   seconds without a manual refresh. This is the part most likely to reveal a hosting-config
   problem if something's off, since basic page loads working doesn't guarantee the streaming
   connection is passing through cleanly.

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| **500.19** or blank error immediately on load | Hosting Bundle not installed (or IIS wasn't restarted after installing it) |
| **502.5 - Process Failure** | App crashed on startup — check **Event Viewer → Windows Logs → Application** for the actual .NET exception, or temporarily enable `stdoutLogEnabled="true"` in `web.config` and check the `logs` folder it creates |
| Page loads, but saving always fails | App pool identity doesn't have write access to its own folder — revisit step 4 |
| Works locally (`dotnet run`) but not through IIS | Almost always an IIS/app-pool config issue rather than app code — recheck "No Managed Code" on the app pool and that the site's physical path is exactly the publish output folder |
| Live-sync doesn't update other tabs | Check the browser console for repeated `EventSource` reconnect errors — if present, something's buffering the SSE stream; double-check `web.config`'s `hostingModel="inprocess"` is actually present (open the generated file and confirm) |
| Works on the server itself, not from other PCs | Same as before — firewall rule or VPN routing, not an app issue |

---

## What changed vs. the Node version, for your own reference

- No Node.js, no `server.js`, no Task Scheduler — IIS now owns process lifecycle, restart-on-
  crash, and startup entirely, which is exactly what "required, standard practice here" gets you.
- Same JSON contract on the wire (`GET/POST /api/data`, `GET /api/events`), so
  `Application_Inventory.html` didn't need to change at all.
- Same optimistic-concurrency conflict handling (version-checked saves, 409 on conflict) and
  same near-real-time push via Server-Sent Events — just implemented in C# instead of Node,
  using a `lock` for thread safety instead of relying on JavaScript's single-threaded model.
