using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace SystemsRegistry
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            // Explicit — UseRouting()/UseEndpoints() below need routing
            // services registered, and this project doesn't pull them in
            // indirectly via AddControllers()/AddMvc() the way a fuller
            // template would.
            services.AddRouting();

            // One DataStore per process, shared by every request — this is
            // the direct equivalent of the module-level `state` variable in
            // server.js.
            services.AddSingleton<DataStore>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // "/" serves Application_Inventory.html directly, same as the
            // Node version. Static files are also reachable by their exact
            // filename automatically (e.g. /Application_Inventory.html).
            var defaultFilesOptions = new DefaultFilesOptions();
            defaultFilesOptions.DefaultFileNames.Clear();
            defaultFilesOptions.DefaultFileNames.Add("Application_Inventory.html");
            app.UseDefaultFiles(defaultFilesOptions);
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGet("/api/data", ApiEndpoints.GetData);
                endpoints.MapPost("/api/data", ApiEndpoints.PostData);
                endpoints.MapGet("/api/events", ApiEndpoints.Events);
            });
        }
    }
}
